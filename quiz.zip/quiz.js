const quizData = [
  {
    question: "Who is the father of Computers?",
    options: ["Charles Babbage", "Newton", "Einstein", "Alan Turing"],
    answer: "Charles Babbage"
  },
  {
    question: "HTML stands for?",
    options: ["Hyper Text Makeup Language", "Hyper Text Markup Language", "High Tech Markup Language", "None"],
    answer: "Hyper Text Markup Language"
  },
  {
    question: "CSS is used for?",
    options: ["Styling", "Database", "Server", "Programming"],
    answer: "Styling"
  }
];

const questionEl = document.getElementById("question");
const answerBtns = document.querySelectorAll(".answer");
const nextBtn = document.getElementById("next-btn");
const resultEl = document.getElementById("result");

let currentQ = 0;
let score = 0;

function loadQuestion() {
  const q = quizData[currentQ];
  questionEl.textContent = q.question;
  answerBtns.forEach((btn, i) => {
    btn.textContent = q.options[i];
    btn.onclick = () => checkAnswer(btn.textContent);
  });
}

function checkAnswer(selected) {
  if (selected === quizData[currentQ].answer) {
    score++;
  }
  currentQ++;
  if (currentQ < quizData.length) {
    nextBtn.style.display = "block";
  } else {
    showResult();
  }
}

nextBtn.addEventListener("click", () => {
  nextBtn.style.display = "none";
  loadQuestion();
});

function showResult() {
  document.getElementById("question-container").style.display = "none";
  resultEl.textContent = `You scored ${score} out of ${quizData.length}`;
}

loadQuestion();